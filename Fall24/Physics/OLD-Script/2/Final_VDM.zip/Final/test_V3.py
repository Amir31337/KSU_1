import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error

# Configuration
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
FILE_PATH = '/home/g/ghanaatian/Documents/PyCharm/pythonProject/Second-Data/10K.csv'
BATCH_SIZE = 512
HIDDEN_DIM = 512
LATENT_DIM = 32

class EncoderDecoder(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_dim, latent_dim):
        super(EncoderDecoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.LeakyReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU(),
            nn.Linear(hidden_dim, latent_dim * 2)  # Output mean and log variance
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim + 1, hidden_dim),  # Ensure this matches the combined size of z and t_emb
            nn.LeakyReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LeakyReLU(),
            nn.Linear(hidden_dim, output_dim)
        )

    def forward(self, x, t):
        z_params = self.encoder(x)
        mu, log_var = torch.chunk(z_params, 2, dim=1)
        std = torch.exp(0.5 * log_var)
        z = mu + std * torch.randn_like(std)

        # Concatenate z and t
        t_emb = t.unsqueeze(1)  # Ensure t has the same batch size as z
        zt = torch.cat([z, t_emb], dim=1)

        # Decode
        y_pred = self.decoder(zt)
        return y_pred, mu, log_var

def load_and_preprocess_data(file_path):
    data = pd.read_csv(file_path)
    momenta = data[['pcx', 'pcy', 'pcz', 'pox', 'poy', 'poz', 'psx', 'psy', 'psz']]
    positions = data[['cx', 'cy', 'cz', 'ox', 'oy', 'oz', 'sx', 'sy', 'sz']]

    scaler_momenta = MinMaxScaler()
    scaler_positions = MinMaxScaler()

    momenta_scaled = scaler_momenta.fit_transform(momenta)
    positions_scaled = scaler_positions.fit_transform(positions)

    return momenta_scaled, positions_scaled, scaler_momenta, scaler_positions, data

def create_dataloader(momenta, positions, batch_size):
    dataset = TensorDataset(torch.FloatTensor(momenta), torch.FloatTensor(positions))
    return DataLoader(dataset, batch_size=batch_size, shuffle=False)

def evaluate_model(model, test_loader, scaler_positions):
    model.eval()
    predictions, targets = [], []

    with torch.no_grad():
        for batch_x, batch_y in test_loader:
            batch_x = batch_x.to(DEVICE)
            y_pred, _, _ = model(batch_x, torch.zeros(batch_x.size(0), device=DEVICE))
            predictions.append(y_pred.cpu().numpy())
            targets.append(batch_y.numpy())

    predictions = np.concatenate(predictions)
    targets = np.concatenate(targets)

    predictions_original = scaler_positions.inverse_transform(predictions)
    targets_original = scaler_positions.inverse_transform(targets)

    mse = mean_squared_error(targets_original, predictions_original)
    r2 = r2_score(targets_original, predictions_original)
    mae = mean_absolute_error(targets_original, predictions_original)

    return mse, r2, mae, predictions_original, targets_original

def main():
    print(f"Using device: {DEVICE}")

    # Load and preprocess data
    momenta, positions, scaler_momenta, scaler_positions, original_data = load_and_preprocess_data(FILE_PATH)

    # Create dataloader
    test_loader = create_dataloader(momenta, positions, BATCH_SIZE)

    # Initialize model
    input_dim = momenta.shape[1]
    output_dim = positions.shape[1]
    model = EncoderDecoder(input_dim, output_dim, HIDDEN_DIM, LATENT_DIM).to(DEVICE)

    # Load trained model
    model.load_state_dict(torch.load('best_model.pth', weights_only=True))

    # Evaluate model
    mse, r2, mae, predictions_original, targets_original = evaluate_model(model, test_loader, scaler_positions)

    # Print 5 random samples
    random_indices = np.random.choice(len(original_data), 5, replace=False)
    for idx in random_indices:
        print(f"\nSample {idx}:")
        real_position = original_data.iloc[idx][['cx', 'cy', 'cz', 'ox', 'oy', 'oz', 'sx', 'sy', 'sz']]
        predicted_position = predictions_original[idx]

        real_position_str = ", ".join([f"{val:.3f}" for val in real_position])
        predicted_position_str = ", ".join([f"{val:.3f}" for val in predicted_position])

        print(f"{'Real Position     :':<20} {real_position_str}")
        print(f"{'Predicted Position:':<20} {predicted_position_str}")

    # Print overall metrics
    print(f"\nOverall Metrics:")
    print(f"MSE: {mse}")
    print(f"R2 Score: {r2}")
    print(f"MAE: {mae}")

if __name__ == '__main__':
    main()