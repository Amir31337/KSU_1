import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import torch
from torch import nn

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

LATENT_DIM = 3
ENCODER_HIDDEN_DIMS = [256, 128]
DECODER_HIDDEN_DIMS = [128, 256]

class VAE(nn.Module):
    def __init__(self, input_dim, output_dim, latent_dim, encoder_hidden_dims, decoder_hidden_dims):
        super(VAE, self).__init__()

        # Encoder
        encoder_layers = []
        prev_dim = input_dim
        for dim in encoder_hidden_dims:
            encoder_layers.extend([nn.Linear(prev_dim, dim), nn.ReLU(), nn.Dropout(0.2)])
            prev_dim = dim
        self.encoder = nn.Sequential(*encoder_layers)

        self.z_mean = nn.Linear(encoder_hidden_dims[-1], latent_dim)
        self.z_log_var = nn.Linear(encoder_hidden_dims[-1], latent_dim)

        # Decoder
        decoder_layers = []
        prev_dim = latent_dim
        for dim in decoder_hidden_dims:
            decoder_layers.extend([nn.Linear(prev_dim, dim), nn.ReLU(), nn.Dropout(0.2)])
            prev_dim = dim
        decoder_layers.append(nn.Linear(prev_dim, output_dim))
        self.decoder = nn.Sequential(*decoder_layers)

    def encode(self, x):
        h = self.encoder(x)
        return self.z_mean(h), self.z_log_var(h)

    def reparameterize(self, mu, log_var):
        std = torch.exp(0.5 * log_var)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z):
        return self.decoder(z)

    def forward(self, x):
        mu, log_var = self.encode(x)
        z = self.reparameterize(mu, log_var)
        return self.decode(z), mu, log_var


# Load the test data
df_test = pd.read_csv('/home/g/ghanaatian/Documents/PyCharm/pythonProject/Second-Data/10K.csv')

# Define column names for momenta and positions
momenta_cols = [f'momentum_{i}' for i in range(1, 10)]
position_cols = [f'position_{i}' for i in range(1, 10)]

# Fit scalers on the entire dataset with feature names
scaler_momenta = StandardScaler().fit(df_test.iloc[:, 10:19].set_axis(momenta_cols, axis=1))
scaler_positions = StandardScaler().fit(df_test.iloc[:, 1:10].set_axis(position_cols, axis=1))

# Load the saved model
input_dim = 9  # 9 momentum values
output_dim = 9  # 9 position values
model = VAE(input_dim, output_dim, LATENT_DIM, ENCODER_HIDDEN_DIMS, DECODER_HIDDEN_DIMS).to(device)
model.load_state_dict(torch.load('V3_TEST.pth', map_location=device, weights_only=True))
model.eval()

def format_list(lst):
    return ', '.join(f"{x:>7.3f}" for x in lst)

def process_row(row_number):
    random_row = df_test.iloc[row_number]

    momenta_real = pd.DataFrame(random_row[10:19]).T.set_axis(momenta_cols, axis=1)
    positions_real = pd.DataFrame(random_row[1:10]).T.set_axis(position_cols, axis=1)

    momenta_normalized = torch.tensor(scaler_momenta.transform(momenta_real), dtype=torch.float32)

    with torch.no_grad():
        predicted_positions, _, _ = model(momenta_normalized.to(device))

    predicted_positions = scaler_positions.inverse_transform(predicted_positions.cpu().numpy())

    positions_str = format_list(positions_real.values.flatten())
    predicted_positions_str = format_list(predicted_positions.flatten())

    mse = np.mean((positions_real.values - predicted_positions.flatten()) ** 2)

    print(f"\nRow number {row_number}")
    print(f"Real positions     : [{positions_str}]")
    print(f"Predicted positions: [{predicted_positions_str}]")
    print(f"Mean Squared Error : {mse:.6f}")

# Generate 5 unique random row numbers
random_rows = np.random.choice(len(df_test), 5, replace=False)

# Process each random row
for row in random_rows:
    process_row(row)

print("\nCalculating metrics for all 10,000 rows...")

all_real_positions = df_test.iloc[:, 1:10].set_axis(position_cols, axis=1)
all_momenta = df_test.iloc[:, 10:19].set_axis(momenta_cols, axis=1)

all_momenta_normalized = torch.tensor(scaler_momenta.transform(all_momenta), dtype=torch.float32)

all_predicted_positions = []

# Process in batches to avoid memory issues
batch_size = 1000
for i in range(0, len(all_momenta_normalized), batch_size):
    batch = all_momenta_normalized[i:i+batch_size]
    with torch.no_grad():
        predicted_batch, _, _ = model(batch.to(device))
    all_predicted_positions.append(predicted_batch.cpu().numpy())

all_predicted_positions = np.concatenate(all_predicted_positions, axis=0)
all_predicted_positions = scaler_positions.inverse_transform(all_predicted_positions)

mse = mean_squared_error(all_real_positions, all_predicted_positions)
r2 = r2_score(all_real_positions, all_predicted_positions)
mae = mean_absolute_error(all_real_positions, all_predicted_positions)

print(f"Mean Squared Error (MSE) for all 10,000 rows: {mse:.6f}")
print(f"R-squared (R2) for all 10,000 rows: {r2:.6f}")
print(f"Mean Absolute Error (MAE) for all 10,000 rows: {mae:.6f}")